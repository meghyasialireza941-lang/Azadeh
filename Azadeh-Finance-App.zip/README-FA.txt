1) محتویات این زیپ رو extract کن و همه‌ی فایل‌ها و پوشه‌ها (با پوشه‌ی .github) رو توی یه ریپازیتوری گیت‌هاب آپلود کن.
2) بعد از آپلود، توی تب Actions بیلد خودکار شروع میشه.
3) وقتی تموم شد، روی بیلد کلیک کن و پایین صفحه از Artifacts فایل Azadeh-Finance-APK رو دانلود کن (داخلش app-debug.apk هست).
اگه پوشه‌ی .github آپلود نشد: توی گیتهاب Add file > Create new file بزن، اسمش رو بذار .github/workflows/build.yml و محتوای build-workflow-copy.yml رو توش بچسبون.
